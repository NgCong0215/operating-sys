#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <semaphore.h>

#define SHM_NAME "/my_shared_memory"

typedef struct{
    char PersonalMsg[256];
    char BroadMsg[256];
    sem_t BroadSem;
    sem_t SendSem;
    sem_t RespondSem;
}SharedData;

int main() {
    int shm_fd;
    SharedData *shm_ptr;

    // 1. Create shared memory
    shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) { perror("shm_open"); exit(1); }

    // 2. Set size
    ftruncate(shm_fd, sizeof(SharedData));

    // 3. Map memory
    shm_ptr = mmap(NULL, sizeof(SharedData), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) { perror("mmap"); exit(1); }

    // 4. Clear memory
    memset(shm_ptr, 0, sizeof(SharedData));

    // 5. Initialize unnamed semaphores in shared memory
    sem_init(&shm_ptr->SendSem, 1, 0);      // server sends to client
    sem_init(&shm_ptr->RespondSem, 1, 0);   // client responds
    sem_init(&shm_ptr->BroadSem, 1, 0);     // broadcast message

    // 6. Example: server sends a personal message
    snprintf(shm_ptr->PersonalMsg, sizeof(shm_ptr->PersonalMsg), "Hello client! Your turn");
    sem_post(&shm_ptr->SendSem);  // signal client

    printf("Server wrote personal message, waiting for client response...\n");

    sem_wait(&shm_ptr->RespondSem);  // wait for client response
    printf("Client responded: %s\n", shm_ptr->PersonalMsg);

    // Broadcast example
    snprintf(shm_ptr->BroadMsg, sizeof(shm_ptr->BroadMsg), "New player has joined the game!");
    sem_post(&shm_ptr->BroadSem);  // signal all clients

    // Sleep to simulate game running
    sleep(10);

    // Cleanup
    sem_destroy(&shm_ptr->SendSem);
    sem_destroy(&shm_ptr->RespondSem);
    sem_destroy(&shm_ptr->BroadSem);

    munmap(shm_ptr, sizeof(SharedData));
    close(shm_fd);
    shm_unlink(SHM_NAME);

    return 0;
}
