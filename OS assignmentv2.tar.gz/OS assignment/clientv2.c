#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <semaphore.h>

#define SHM_NAME "/my_shared_memory"

// This must match the server's struct exactly
typedef struct {
    char PersonalMsg[256];
    char BroadMsg[256];
    sem_t BroadSem;
    sem_t SendSem;
    sem_t RespondSem;
} SharedData;

int main() {
    int shm_fd;
    SharedData *shm_ptr;

    // 1. Open the existing shared memory created by server
    shm_fd = shm_open(SHM_NAME, O_RDWR, 0666);  // must be O_RDWR to write response
    if (shm_fd == -1) {
        perror("shm_open");
        exit(1);
    }

    // 2. Map shared memory
    shm_ptr = mmap(NULL, sizeof(SharedData), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    // 3. Wait for personal message from server
    sem_wait(&shm_ptr->SendSem);   // wait until server sends
    printf("Client received personal message: %s\n", shm_ptr->PersonalMsg);

    // 4. Respond to server
    snprintf(shm_ptr->PersonalMsg, sizeof(shm_ptr->PersonalMsg), "Client ready! Let's play!");
    sem_post(&shm_ptr->RespondSem);   // signal server we responded

    // 5. Wait for broadcast message from server
    sem_wait(&shm_ptr->BroadSem);   // wait for server broadcast
    printf("Client received broadcast: %s\n", shm_ptr->BroadMsg);

    // 6. Cleanup
    munmap(shm_ptr, sizeof(SharedData));
    close(shm_fd);

    return 0;
}
