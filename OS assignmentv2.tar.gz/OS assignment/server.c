#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <semaphore.h>

#define SHM_NAME "/my_shared_memory"
#define SEM_NAME "/my_sem"
#define SHM_SIZE 1024

typedef struct{
    char PersonalMsg[256];
    char BroadMsg[256];
    sem_t BroadSem;
    sem_t SendSem;
    sem_t RespondSem;
}SharedData;

int main() {
    int shm_fd;
    SharedData *shm_ptr;
    sem_t *sem;

    // Create shared memory object
    shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open");
        exit(1);
    }

    // Set size of shared memory
    ftruncate(shm_fd, SHM_SIZE);

    // Map shared memory
    shm_ptr = mmap(NULL, SHM_SIZE, PROT_WRITE | PROT_READ, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    sem = sem_open(SEM_NAME, O_CREAT, 0666, 0);
    if (sem == SEM_FAILED){
        perror("sem open");
        exit(1);
    }

    // Write data
    snprintf(shm_ptr->PersonalMsg, sizeof(shm_ptr->PersonalMsg), "Hello client! Turn");

    printf("Server wrote: %s\n", shm_ptr->PersonalMsg);

    sem_post(sem);
    
    sleep(10);

    sem_wait(sem);

    printf("Client wrote: %s\n", shm_ptr->PersonalMsg);
    memset(shm_ptr->PersonalMsg, 0, sizeof(shm_ptr->PersonalMsg));

    sem_post(sem);


    // Cleanup
    munmap(shm_ptr, SHM_SIZE);
    close(shm_fd);
    sem_close(sem);
    sem_unlink(SEM_NAME);
    shm_unlink(SHM_NAME);

    return 0;
}
