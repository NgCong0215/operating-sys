#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <semaphore.h>

#define SHM_NAME "/my_shared_memory"
#define SEM_NAME "/my_sem"
#define SHM_SIZE 1024

int main() {
    int shm_fd;
    char *shm_ptr;
    sem_t *sem;

    sem = sem_open(SEM_NAME, 0);
    if (sem == SEM_FAILED){
        perror("sem open");
        exit(1);
    }

    sem_wait(sem);

    // Open existing shared memory
    shm_fd = shm_open(SHM_NAME, O_RDONLY, 0666);
    if (shm_fd == -1) {
        perror("shm_open");
        exit(1);
    }

    // Map shared memory
    shm_ptr = mmap(NULL, SHM_SIZE, PROT_READ, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    // Read data
    printf("Client read: %s\n", shm_ptr);

    // Cleanup
    munmap(shm_ptr, SHM_SIZE);
    close(shm_fd);

    return 0;
}
